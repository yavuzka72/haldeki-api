<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Log;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;   // <-- ekle

class User extends Authenticatable implements FilamentUser {
	/** @use HasFactory<\Database\Factories\UserFactory> */
	use HasApiTokens, HasFactory, Notifiable,SoftDeletes;

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var list<string>
	 */
	protected $fillable = [
	    'name',
        'email',
        'password',
        'user_type', 'country_id', 'city_id', 'address',  'email_verified_at','dealer_id',
        'player_id', 'latitude', 'longitude', 'status', 'last_notification_seen' , 'login_type', 'uid', 'fcm_token', 'otp_verify_at'
        ,'app_version', 'last_location_update_at', 'app_source','is_active'

	];

	/**
	 * The attributes that should be hidden for serialization.
	 *
	 * @var list<string>
	 */
	protected $hidden = [
		'password',
		'remember_token',
	];

	/**
	 * Get the attributes that should be cast.
	 *
	 * @return array<string, string>
	 */
	protected function casts(): array {
		return [
			'email_verified_at' => 'datetime',
			'password' => 'hashed',
			'admin' => 'boolean',
			'admin_level' => 'integer',
		];
	}

	public function canAccessPanel(Panel $panel): bool {
		return $this->admin;
	}
	/*

	public function products(): BelongsToMany {
		return $this->belongsToMany(Product::class, 'user_products')
			->withTimestamps()
			->withPivot('active')
			->where('user_products.active', true);
	}
*/
	public function productPrices(): HasMany {
		return $this->hasMany(UserProductPrice::class);
	}

	public function cart() {
		return $this->hasOne(Cart::class);
	}

	public function orders() {
		return $this->hasMany(Order::class);
	}

	public function sellerOrders() {
		return $this->hasMany(OrderItem::class, 'dealer_id');
	}

	public function userProducts(): BelongsToMany
	{
		return $this->belongsToMany(Product::class, 'user_products')
			->withPivot('active')
			->withTimestamps();
	}
	
	
	   public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'user_products', 'user_id', 'product_id')
            ->withPivot(['active'])
            ->withTimestamps();
    }
    
        public function activeProducts(): BelongsToMany
    {
        return $this->products()->wherePivot('active', 1);
    }

	  public function country(){
        return $this->belongsTo(Country::class, 'country_id','id');
    }

    public function city(){
        return $this->belongsTo(City::class, 'city_id','id');
    }
  public function deliveryManOrder(){
        return $this->hasMany(Order::class,'delivery_man_id','id')->withTrashed();
    }

    public function deliveryManDocument(){
        return $this->hasMany(DeliveryManDocument::class,'delivery_man_id', 'id')->withTrashed();
    }

    public function userBankAccount() {
        return $this->hasOne(UserBankAccount::class, 'user_id', 'id');
    }

    public function userWallet() {
        return $this->hasOne(Wallet::class, 'user_id', 'id');
    }

    public function userWithdraw(){
        return $this->hasMany(WithdrawRequest::class, 'user_id', 'id');
    }

    public function userAddress() {
        return $this->hasMany(UserAddress::class, 'user_id', 'id');
    }

	  public function getPayment()
    {
        return $this->hasManyThrough( 
            Payment::class,
            Order::class,
            'delivery_man_id',
            'order_id',
            'id',
            'id'
        )->where('payment_status','paid');
    }

    public function userWalletHistory(){
        return $this->hasMany(WalletHistory::class, 'user_id', 'id');
    }
}
