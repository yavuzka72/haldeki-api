<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CashReportController extends Controller
{
    public function index(Request $request)
    {
        // Filtre parametreleri (opsiyonel)
        $from      = $request->query('from');      // 2025-11-01
        $to        = $request->query('to');        // 2025-11-12
        $dealerId  = $request->query('dealer_id'); // bayi_id
        $courierId = $request->query('courier_id'); // kurye_id

        // ---------------------------------------------------------------------
        // 1) Günlük Kasa Özeti (vw_gunluk_kasa_ozet)
        // ---------------------------------------------------------------------

        $daily = DB::table('vw_gunluk_kasa_ozet')
            ->when($from && $to, function ($q) use ($from, $to) {
                $q->whereBetween('tarih', [$from, $to]);
            })
            ->when($dealerId, function ($q) use ($dealerId) {
                $q->where('bayi_id', $dealerId);
            })
            ->when($courierId, function ($q) use ($courierId) {
                $q->where('kurye_id', $courierId);
            })
            ->orderBy('tarih')
            ->get([
                'tarih',
                'musteri_tahsilat',
                'tedarikci_odeme',
                'kurye_odeme',
                'bayi_komisyonu',
            ]);

        // ---------------------------------------------------------------------
        // 2) Müşteri Tahsilat Detayı (vw_musteri_tahsilat_detay)
        // ---------------------------------------------------------------------

        $customers = DB::table('vw_musteri_tahsilat_detay')
            ->when($from && $to, function ($q) use ($from, $to) {
                $q->whereBetween('islem_tarihi', [$from, $to]);
            })
            ->when($dealerId, function ($q) use ($dealerId) {
                $q->where('bayi_id', $dealerId);
            })
            ->when($courierId, function ($q) use ($courierId) {
                $q->where('kurye_id', $courierId);
            })
            ->orderBy('islem_tarihi')
            ->get([
                'islem_tarihi',
                'delivery_order_id',
                'kaynak_order_id',
                'musteri_adi',
                'siparis_tutari',
                'tahsil_edilen_tutar',
                'odeme_durumu',
                'siparis_durumu',
            ]);

        // ---------------------------------------------------------------------
        // 3) Tedarikçi Ödemeleri (vw_tedarikci_odeme_detay)
        // ---------------------------------------------------------------------

        $suppliers = DB::table('vw_tedarikci_odeme_detay')
            ->when($from && $to, function ($q) use ($from, $to) {
                $q->whereBetween('islem_tarihi', [$from, $to]);
            })
            ->when($dealerId, function ($q) use ($dealerId) {
                $q->where('bayi_id', $dealerId);
            })
            ->orderBy('islem_tarihi')
            ->get([
                'islem_tarihi',
                'order_id',
                'siparis_kodu',
                'tedarikci_adi',
                'siparis_tutari',
                'tedarikci_odeme_tutari',
                'siparis_durumu',
                'odeme_durumu',
            ]);

        // ---------------------------------------------------------------------
        // 4) Kurye Ödemeleri (vw_kurye_odeme_detay)
        // ---------------------------------------------------------------------

        $couriers = DB::table('vw_kurye_odeme_detay')
            ->when($from && $to, function ($q) use ($from, $to) {
                $q->whereBetween('islem_tarihi', [$from, $to]);
            })
            ->when($dealerId, function ($q) use ($dealerId) {
                $q->where('bayi_id', $dealerId);
            })
            ->when($courierId, function ($q) use ($courierId) {
                $q->where('kurye_id', $courierId);
            })
            ->orderBy('islem_tarihi')
            ->get([
                'islem_tarihi',
                'delivery_order_id',
                'kaynak_order_id',
                'kurye_adi',
                'siparis_tutari',
                'kurye_odeme_tutari',
                'teslimat_durumu',
                'odeme_durumu',
            ]);

        // ---------------------------------------------------------------------
        // 5) Bayi Komisyonları (vw_bayi_komisyon_detay)
        // ---------------------------------------------------------------------

        $vendors = DB::table('vw_bayi_komisyon_detay')
            ->when($from && $to, function ($q) use ($from, $to) {
                $q->whereBetween('islem_tarihi', [$from, $to]);
            })
            ->when($dealerId, function ($q) use ($dealerId) {
                $q->where('bayi_id', $dealerId);
            })
            ->orderBy('islem_tarihi')
            ->get([
                'islem_tarihi',
                'order_id',
                'siparis_kodu',
                'bayi_adi',
                'siparis_tutari',
                'bayi_komisyon_tutari',
                'siparis_durumu',
                'odeme_durumu',
            ]);

        // ---------------------------------------------------------------------
        // RESPONSE
        // ---------------------------------------------------------------------

        return response()->json([
            'daily'     => $daily,
            'customers' => $customers,
            'suppliers' => $suppliers,
            'couriers'  => $couriers,
            'vendors'   => $vendors,
        ]);
    }
}
